// routes/employeeRoutes.js
const express = require('express');
const employeeController = require('../controllers/employeeController');

const router = express.Router();

router.get('/employees', employeeController.getEmployees);
router.get('/employees/:eid', employeeController.getEmployeeById);
router.post('/employees', employeeController.addEmployee);
router.put('/employees/:eid', employeeController.updateEmployeeById);
router.delete('/employees', employeeController.deleteEmployeeById);

module.exports = router;