const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const userRoutes = require('./routes/userRoutes');
const employeeRoutes = require('./routes/employeeRoutes');

const app = express();
const port = 3001;

// Use body-parser middleware
app.use(bodyParser.json());

app.use(express.json())
app.use(express.urlencoded())
// MongoDB connection string
const mongoURI = 'mongodb+srv://hilaltozlu3718:ybVpYBCCFuNR4h05@cluster0.0igkr67.mongodb.net/?retryWrites=true&w=majority'

// Connect to MongoDB
mongoose.connect(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true });

// Use routes
app.use('/api/v1/user', userRoutes);
app.use('/api/v1/employee', employeeRoutes);

app.route("/")

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});