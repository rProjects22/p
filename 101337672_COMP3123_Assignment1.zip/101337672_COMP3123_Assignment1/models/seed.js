const mongoose = require('mongoose');
const Employee = require('./models/Employee');
const User = require('./models/User');

// MongoDB connection string
const mongoURI = 'mongodb+srv://hilaltozlu3718:ybVpYBCCFuNR4h05@cluster0.0igkr67.mongodb.net/?retryWrites=true&w=majority'

// Connect to MongoDB
mongoose.connect(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true });

// Check for connection errors
mongoose.connection.on('error', err => {
  console.error('MongoDB connection error:', err);
});

// Connection successful
mongoose.connection.once('open', () => {
  console.log('Connected to MongoDB');
});

// Example for creating and saving an employee
const newEmployee = new Employee({
  _id: new mongoose.Types.ObjectId(),
  first_name: 'John',
  last_name: 'Doe',
  email: 'john.doe@example.com',
  gender: 'Male',
  salary: 50000,
});

newEmployee.save()
  .then(result => {
    console.log('Employee saved:', result);
  })
  .catch(error => {
    console.error('Error saving employee:', error);
  });

// Example for creating and saving a user
const newUser = new User({
  _id: new mongoose.Types.ObjectId(),
  username: 'john_doe',
  email: 'john.doe@example.com',
  password: 'somepassword', 
});

newUser.save()
  .then(result => {
    console.log('User saved:', result);
  })
  .catch(error => {
    console.error('Error saving user:', error);
  });

