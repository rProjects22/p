// controllers/employeeController.js
const Employee = require('../models/Employee');

const getEmployees = async (req, res) => {
    try {
        const employees = await Employee.find();
        res.status(200).json({ status: true, employees });
    } catch (error) {
        console.error(error);
        res.status(500).json({ status: false, message: 'Internal Server Error' });
    }
};

const getEmployeeById = async (req, res) => {
    const { eid } = req.params;

    try {
        const employee = await Employee.findById(eid);
        if (employee) {
            res.status(200).json({ status: true, employee });
        } else {
            res.status(404).json({ status: false, message: 'Employee not found' });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ status: false, message: 'Internal Server Error' });
    }
};

const addEmployee = async (req, res) => {
    const { first_name, last_name, email, gender, salary } = req.body;

    try {
        const employee = new Employee({ first_name, last_name, email, gender, salary });
        await employee.save();
        res.status(201).json({ status: true, message: 'Employee added successfully', employee });
    } catch (error) {
        console.error(error);
        res.status(500).json({ status: false, message: 'Internal Server Error' });
    }
};

const updateEmployeeById = async (req, res) => {
    const { eid } = req.params;
    const { first_name, last_name, email, gender, salary } = req.body;

    try {
        const updatedEmployee = await Employee.findByIdAndUpdate(
            eid,
            { first_name, last_name, email, gender, salary },
            { new: true }
        );

        if (updatedEmployee) {
            res.status(200).json({ status: true, message: 'Employee updated successfully', employee: updatedEmployee });
        } else {
            res.status(404).json({ status: false, message: 'Employee not found' });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ status: false, message: 'Internal Server Error' });
    }
};

const deleteEmployeeById = async (req, res) => {
    const { eid } = req.query;

    try {
        const deletedEmployee = await Employee.findByIdAndDelete(eid);
        if (deletedEmployee) {
            res.status(204).json(); // No content, as the employee has been deleted
        } else {
            res.status(404).json({ status: false, message: 'Employee not found' });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ status: false, message: 'Internal Server Error' });
    }
};

module.exports = { getEmployees, getEmployeeById, addEmployee, updateEmployeeById, deleteEmployeeById };